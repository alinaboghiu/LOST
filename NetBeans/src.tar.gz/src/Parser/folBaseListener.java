// Generated from fol.g4 by ANTLR 4.0
package Parser;

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.tree.TerminalNode;
import org.antlr.v4.runtime.tree.ErrorNode;

public class folBaseListener implements folListener {

    @Override
    public void enterQuantifier(folParser.QuantifierContext ctx) {
    }

    @Override
    public void exitQuantifier(folParser.QuantifierContext ctx) {
    }

    @Override
    public void enterTerm(folParser.TermContext ctx) {
    }

    @Override
    public void exitTerm(folParser.TermContext ctx) {
    }

    @Override
    public void enterCondition(folParser.ConditionContext ctx) {
    }

    @Override
    public void exitCondition(folParser.ConditionContext ctx) {
    }

    @Override
    public void enterUnaryarg(folParser.UnaryargContext ctx) {
    }

    @Override
    public void exitUnaryarg(folParser.UnaryargContext ctx) {
    }

    @Override
    public void enterRelation(folParser.RelationContext ctx) {
    }

    @Override
    public void exitRelation(folParser.RelationContext ctx) {
    }

    @Override
    public void enterBinaryarg(folParser.BinaryargContext ctx) {
    }

    @Override
    public void exitBinaryarg(folParser.BinaryargContext ctx) {
    }

    @Override
    public void enterFormula(folParser.FormulaContext ctx) {
    }

    @Override
    public void exitFormula(folParser.FormulaContext ctx) {
    }

    @Override
    public void enterEveryRule(ParserRuleContext ctx) {
    }

    @Override
    public void exitEveryRule(ParserRuleContext ctx) {
    }

    @Override
    public void visitTerminal(TerminalNode node) {
    }

    @Override
    public void visitErrorNode(ErrorNode node) {
    }
}