package Tree;

/*
 * @author alina
 *
 */
public class ThisUnboundException extends Exception {
}
