package Tree;

/*
 * @author alina
 * 
 */
public class Constant extends Term {

    public Constant(String name) {
        super(name);
    }
}
