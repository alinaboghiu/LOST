package Tree;

/*
 * @author alina
 * 
 */
public class DuplicateDefinitionException extends Exception {
}
