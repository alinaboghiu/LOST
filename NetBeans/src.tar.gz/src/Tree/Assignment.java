package Tree;

/*
 * @author alina
 * 
 */
class Assignment {

    Term assignedTerm;
    Variable boundVar;
}
